$(document).ready(function(){
	
	$('nav ul li a').css( {backgroundPosition: "0 -4px"} )
		.mouseover(function(){
			$(this).stop().animate({
				backgroundPosition: "(0 -40px)",
				"color": "#333"
			}, {duration:400})
		})
		.mouseout(function(){
			$(this).stop().animate({
				backgroundPosition:"(0 -4px)",
				"color": "#ccc"
			}, {duration:"slow"})
		})
		
	$('nav ul li.ideas a').css( {backgroundPosition: "0 -3px"} )
		.mouseover(function(){
			$(this).stop().animate({
				backgroundPosition: "(0 -37px)",
				"color": "#333"
			}, {duration:400})
		})
		.mouseout(function(){
			$(this).stop().animate({
				backgroundPosition:"(0 -3px)",
				"color": "#ccc"
			}, {duration:"slow"})
		})
		
	$('nav ul li.contact a').css( {backgroundPosition: "0 0px"} )
		.mouseover(function(){
			$(this).stop().animate({
				backgroundPosition: "(0 -30px)",
				"color": "#333"
			}, {duration:400})
		})
		.mouseout(function(){
			$(this).stop().animate({
				backgroundPosition:"(0 0px)",
				"color": "#ccc"
			}, {duration:"slow"})
		})
	
	$("body").css('background-position', '0px ' + ($(window).width() - 1024)/2 - 100);
	
	
	
});